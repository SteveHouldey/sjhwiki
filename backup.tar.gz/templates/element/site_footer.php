<footer class="site-footer">
    <div class="site-footer-inner">
        <p>&copy; <?= h(gmdate('Y')) ?> Steven Houldey</p>
        <nav aria-label="Footer navigation">
            <?= $this->Html->link('About', '/about') ?>
            <?= $this->Html->link('Search', '/search') ?>
        </nav>
    </div>
</footer>
